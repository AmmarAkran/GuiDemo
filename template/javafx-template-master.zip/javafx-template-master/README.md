![Korotkin's Logo](http://www.korotkin.co.il/logo.png)

# javafx-template
JavaFX with Maven Quickstart
